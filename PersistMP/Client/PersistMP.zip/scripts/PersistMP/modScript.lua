----- modScript -----
---------------------
----- PersistMP -----
---------------------
---- Authored by ----
-- Beams of Norway --
---------------------

print("Loading PersistMP...")
load('PersistMP')
setExtensionUnloadMode("PersistMP", 'manual')
print("PersistMP loaded...")